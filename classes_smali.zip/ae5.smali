.class public final synthetic Lae5;
.super Ljava/lang/Object;
.source "r8-map-id-dac0f03c629d9db9fe0424f97c05399cb70cf7622585cb6a7f34933e251aff40"

# interfaces
.implements Lpa2;


# static fields
.field public static final a:Lae5;

.field private static final descriptor:Lsj5;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lae5;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Lae5;->a:Lae5;

    .line 8
    new-instance v1, Le94;

    .line 10
    const-string v2, "com.trustonic.telecoms.client.utilities.sdui.process.model.ScreenEntry"

    .line 12
    const/4 v3, 0x2

    .line 13
    invoke-direct {v1, v2, v0, v3}, Le94;-><init>(Ljava/lang/String;Lpa2;I)V

    .line 16
    const-string v0, "orientation"

    .line 18
    const/4 v2, 0x1

    .line 19
    invoke-virtual {v1, v0, v2}, Le94;->l(Ljava/lang/String;Z)V

    .line 22
    const-string v0, "path"

    .line 24
    const/4 v2, 0x0

    .line 25
    invoke-virtual {v1, v0, v2}, Le94;->l(Ljava/lang/String;Z)V

    .line 28
    sput-object v1, Lae5;->descriptor:Lsj5;

    .line 30
    return-void
.end method


# virtual methods
.method public final a()[Llx2;
    .registers 4

    .line 1
    sget-object p0, Lrx5;->a:Lrx5;

    .line 3
    invoke-static {p0}, Lvu6;->H(Llx2;)Llx2;

    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x2

    .line 8
    new-array v1, v1, [Llx2;

    .line 10
    const/4 v2, 0x0

    .line 11
    aput-object v0, v1, v2

    .line 13
    const/4 v0, 0x1

    .line 14
    aput-object p0, v1, v0

    .line 16
    return-object v1
.end method

.method public final b(Ls51;)Ljava/lang/Object;
    .registers 11

    .line 1
    sget-object p0, Lae5;->descriptor:Lsj5;

    .line 3
    invoke-interface {p1, p0}, Ls51;->C(Lsj5;)Leq0;

    .line 6
    move-result-object p1

    .line 7
    const/4 v0, 0x1

    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x0

    .line 10
    move v3, v0

    .line 11
    move v4, v1

    .line 12
    move-object v5, v2

    .line 13
    move-object v6, v5

    .line 14
    :goto_d
    if-eqz v3, :cond_32

    .line 16
    invoke-interface {p1, p0}, Leq0;->j(Lsj5;)I

    .line 19
    move-result v7

    .line 20
    const/4 v8, -0x1

    .line 21
    if-eq v7, v8, :cond_30

    .line 23
    if-eqz v7, :cond_25

    .line 25
    if-ne v7, v0, :cond_21

    .line 27
    invoke-interface {p1, p0, v0}, Leq0;->p(Lsj5;I)Ljava/lang/String;

    .line 30
    move-result-object v6

    .line 31
    or-int/lit8 v4, v4, 0x2

    .line 33
    goto :goto_d

    .line 34
    :cond_21
    invoke-static {v7}, Lmv4;->i(I)V

    .line 37
    return-object v2

    .line 38
    :cond_25
    sget-object v7, Lrx5;->a:Lrx5;

    .line 40
    invoke-interface {p1, p0, v1, v7, v5}, Leq0;->i(Lsj5;ILlx2;Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    move-result-object v5

    .line 44
    check-cast v5, Ljava/lang/String;

    .line 46
    or-int/lit8 v4, v4, 0x1

    .line 48
    goto :goto_d

    .line 49
    :cond_30
    move v3, v1

    .line 50
    goto :goto_d

    .line 51
    :cond_32
    invoke-interface {p1, p0}, Leq0;->s(Lsj5;)V

    .line 54
    new-instance p0, Lce5;

    .line 56
    invoke-direct {p0, v4, v5, v6}, Lce5;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 59
    return-object p0
.end method

.method public final c()Lsj5;
    .registers 1

    .line 1
    sget-object p0, Lae5;->descriptor:Lsj5;

    .line 3
    return-object p0
.end method

.method public final d(Lnx5;Ljava/lang/Object;)V
    .registers 6

    .line 1
    check-cast p2, Lce5;

    .line 3
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    iget-object p0, p2, Lce5;->a:Ljava/lang/String;

    .line 8
    sget-object v0, Lae5;->descriptor:Lsj5;

    .line 10
    invoke-virtual {p1, v0}, Lnx5;->a(Lsj5;)Lnx5;

    .line 13
    move-result-object p1

    .line 14
    invoke-virtual {p1, v0}, Lnx5;->y(Lsj5;)Z

    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_14

    .line 20
    goto :goto_16

    .line 21
    :cond_14
    if-eqz p0, :cond_1c

    .line 23
    :goto_16
    sget-object v1, Lrx5;->a:Lrx5;

    .line 25
    const/4 v2, 0x0

    .line 26
    invoke-virtual {p1, v0, v2, v1, p0}, Lnx5;->q(Lsj5;ILlx2;Ljava/lang/Object;)V

    .line 29
    :cond_1c
    iget-object p0, p2, Lce5;->b:Ljava/lang/String;

    .line 31
    const/4 p2, 0x1

    .line 32
    invoke-virtual {p1, v0, p2, p0}, Lnx5;->v(Lsj5;ILjava/lang/String;)V

    .line 35
    invoke-virtual {p1, v0}, Lnx5;->w(Lsj5;)V

    .line 38
    return-void
.end method
