.class public interface abstract Lb25;
.super Ljava/lang/Object;
.source "r8-map-id-dac0f03c629d9db9fe0424f97c05399cb70cf7622585cb6a7f34933e251aff40"


# virtual methods
.method public abstract a(La25;Luj3;Ljava/util/Map;Lx82;Lv92;I)V
.end method

.method public abstract b()Ljava/lang/String;
.end method
