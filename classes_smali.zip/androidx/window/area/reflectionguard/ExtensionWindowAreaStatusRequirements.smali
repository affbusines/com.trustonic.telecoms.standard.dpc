.class public interface abstract Landroidx/window/area/reflectionguard/ExtensionWindowAreaStatusRequirements;
.super Ljava/lang/Object;
.source "r8-map-id-dac0f03c629d9db9fe0424f97c05399cb70cf7622585cb6a7f34933e251aff40"


# virtual methods
.method public abstract getWindowAreaDisplayMetrics()Landroid/util/DisplayMetrics;
.end method

.method public abstract getWindowAreaStatus()I
.end method
