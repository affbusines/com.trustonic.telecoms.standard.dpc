.class public final Landroidx/work/WorkerParameters;
.super Ljava/lang/Object;
.source "r8-map-id-dac0f03c629d9db9fe0424f97c05399cb70cf7622585cb6a7f34933e251aff40"


# instance fields
.field public a:Ljava/util/UUID;

.field public b:Lt31;

.field public c:I

.field public d:Ljava/util/concurrent/ExecutorService;

.field public e:Lfz0;
